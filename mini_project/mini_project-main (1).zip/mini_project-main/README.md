# Human Crowd Monitoring System


* Download the following files and place it in the same directory
   - https://pjreddie.com/media/files/yolov3.weights


